//
//  Env.swift
//  WeatherForecast
//
//  Created by Kathryn Verkhogliad on 12.03.2025.
//

import Foundation

let apiKey = "849f46651cab14d3cfe36c4a8892a1bf"
