//
//  WeatherForecastTests.swift
//  WeatherForecastTests
//
//  Created by Kathryn Verkhogliad on 25.03.2025.
//

import XCTest
import RxSwift
import RxTest
@testable import WeatherForecast

final class WeatherForecastDecoderTests: XCTestCase {
    var scheduler: TestScheduler!
    var disposeBag: DisposeBag!
    
    override func setUpWithError() throws {
        try super.setUpWithError()
        
        scheduler = TestScheduler(initialClock: 0)
        disposeBag = DisposeBag()
    }
    
    /**
     * Tests  successful fetching of city coordinates.
     * Expected result: the correct city name ("Kyiv") with corresponding latitude and longitude is returned.
     */
    func testFetchCityCoordinatesSuccess() {
        let expectedModel = CoordinatesModel(name: "Kyiv", lat: 40.0, lon: 40.0)
        let ignoredData = CoordinatesModel(name: "Berlin", lat: 30.0, lon: 10.0)
        
        let mockData = try! JSONEncoder().encode([expectedModel, ignoredData])
        let mockService = MockNetworkingService(response: .just(mockData))
        let weatherService = OpenWeatherService(networkingService: mockService)
                
        let fetchedCoordinates = weatherService.fetchCityCoordinatess(for: expectedModel.name)
            
        let observer = scheduler.createObserver(CoordinatesModel.self)

        scheduler.scheduleAt(0) {
            fetchedCoordinates
                .asObservable()
                .subscribe(observer)
                .disposed(by: self.disposeBag)
        }
        
        scheduler.start()
        
        let results = observer.events.compactMap {$0.value.element}
        
        XCTAssertEqual(results.count, 1)
        XCTAssertEqual(results.first?.name, expectedModel.name)
    }
    
    /**
     * Tests failure in fetching city coordinates.
     * Expected result: a DecodingError is returned.
     */
    func testFetchCityCoordinatesFailure() {
        let mockService = MockNetworkingService(response: .error(DecodingError.failedToDecode))
        let weatherService = OpenWeatherService(networkingService: mockService)
        
        let observer = scheduler.createObserver(CoordinatesModel.self)
        
        scheduler.scheduleAt(0) {
            weatherService.fetchCityCoordinatess(for: "")
                .asObservable()
                .subscribe(observer)
                .disposed(by: self.disposeBag)
        }
        
        scheduler.start()
        
        let results = observer.events.compactMap {$0.value}
        
        XCTAssertEqual(results.count, 1)
        XCTAssertTrue(results.first?.error is DecodingError)
    }
    
    /**
     * Tests  successful fetching of a week weather forecast.
     * Expected result: the forecast contains one entry, and contains a weather condition "Clear".
     */
    func testFetchWeekForecastSuccess() {
        let expectedModel = WeekWeatherForecastModel(list: [
            DayForecastModel(
                dt: 1700000000,
                main: DayForecastMainModel(temp: 22.5),
                weather: [DayForecastWeatherModel(main: "Clear", icon: "01d")],
                wind: DayForecastWindModel(speed: 5.0),
                rain: DayForecastRainModel(threeHours: 0.0)
            )
        ])
        let mockData = try! JSONEncoder().encode(expectedModel)
        let mockService = MockNetworkingService(response: .just(mockData))
        let weatherService = OpenWeatherService(networkingService: mockService)
        
        let observer = scheduler.createObserver(WeekWeatherForecastModel.self)
        
        scheduler.scheduleAt(0) {
            weatherService.fetchWeekForecast(lat: 30.0, lon: 30.0)
                .asObservable()
                .subscribe(observer)
                .disposed(by: self.disposeBag)
        }
        
        scheduler.start()
        
        let results = observer.events.compactMap {$0.value.element}
                
        XCTAssertEqual(results.count, 1)
        XCTAssertEqual(results.first?.list.count, 1)
        XCTAssertEqual(results.first?.list.first?.weather.first?.main, "Clear")
    }
       
    /**
     * Tests failure in fetching a week weather forecast.
     * Expected result: a DecodingError is returned.
     */
    func testFetchWeekForecastFailure() {
        let mockService = MockNetworkingService(response: .error(DecodingError.failedToDecode))
        let weatherService = OpenWeatherService(networkingService: mockService)
        
        let observer = scheduler.createObserver(WeekWeatherForecastModel.self)
        
        scheduler.scheduleAt(0) {
            weatherService.fetchWeekForecast(lat: 0, lon: 0)
                .asObservable()
                .subscribe(observer)
                .disposed(by: self.disposeBag)
        }
        
        scheduler.start()
        
        let results = observer.events.compactMap {$0.value}
        
        XCTAssertEqual(results.count, 1)
        XCTAssertTrue(results.first?.error is DecodingError)
    }
    
    /**
     * Tests successful fetching of a weather image.
     * Expected result: a valid UIImage object.
     */
    func testFetchWeatherImageSuccess() {
        let expectedImage = UIImage(systemName: "cloud.sun.fill")!
        let mockService = MockNetworkingService(response: .just(expectedImage.pngData()!))
        let weatherService = OpenWeatherService(networkingService: mockService)
        
        let observer = scheduler.createObserver(UIImage.self)
        
        scheduler.scheduleAt(0) {
            weatherService.fetchWeatherImage(with: "cloudSunIconId")
                .asObservable()
                .subscribe(observer)
                .disposed(by: self.disposeBag)
        }
        
        scheduler.start()
        
        let results = observer.events.compactMap {$0.value.element}
        
        XCTAssertEqual(results.count, 1)
    }
    
    /**
     * Tests failure in fetching a weather image.
     * Expected result: a DecodingError is returned.
     */
    func testFetchWeatherImageFailure() {
        let mockService = MockNetworkingService(response: .error(DecodingError.failedToDecode))
        let weatherService = OpenWeatherService(networkingService: mockService)
        
        let observer = scheduler.createObserver(UIImage.self)
        
        scheduler.scheduleAt(0) {
            weatherService.fetchWeatherImage(with: "invalidId")
                .asObservable()
                .subscribe(observer)
                .disposed(by: self.disposeBag)
        }
        
        scheduler.start()
        
        let results = observer.events.compactMap {$0.value}
        
        XCTAssertEqual(results.count, 1)
        XCTAssertTrue(results.first?.error is DecodingError)
    }
    
    override func tearDownWithError() throws {
        scheduler.scheduleAt(1000, action: { [weak self] in
            self?.disposeBag = nil
        })
        
        scheduler = nil
    }
}
