//
//  TodoListApp.swift
//  TodoList
//
//  Created by Kathryn Verkhogliad on 01.04.2025.
//

import SwiftUI

@main
struct TodoListApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
