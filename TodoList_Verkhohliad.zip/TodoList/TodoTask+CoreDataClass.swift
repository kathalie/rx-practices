//
//  TodoTask+CoreDataClass.swift
//  TodoList
//
//  Created by Kathryn Verkhogliad on 01.04.2025.
//
//

import Foundation
import CoreData


public class TodoTask: NSManagedObject {

}
